const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("touchdeck", {
  getConfig: () => ipcRenderer.invoke("get-config"),
  getIcon: (name) => ipcRenderer.invoke("get-icon", name),
  press: (id) => ipcRenderer.invoke("press", id),
  startDrag: () => ipcRenderer.send("start-drag"),
  debugShot: () => ipcRenderer.invoke("debug-shot"),
});
